package kotlin.ranges;

import kotlin.Metadata;

/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"kotlin/ranges/RangesKt__RangesKt", "kotlin/ranges/RangesKt___RangesKt"}, k = 4, mv = {1, 9, 0}, xi = 49)
public final class RangesKt extends RangesKt___RangesKt {
    private RangesKt() {
    }
}
