package kotlin;

/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"kotlin/PreconditionsKt__AssertionsJVMKt", "kotlin/PreconditionsKt__PreconditionsKt"}, k = 4, mv = {1, 9, 0}, xi = 49)
public final class PreconditionsKt extends PreconditionsKt__PreconditionsKt {
    private PreconditionsKt() {
    }
}
