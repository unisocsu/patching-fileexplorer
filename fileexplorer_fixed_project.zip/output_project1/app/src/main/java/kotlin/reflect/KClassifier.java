package kotlin.reflect;

import kotlin.Metadata;

/* JADX INFO: compiled from: KClassifier.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\n\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\bg\u0018\u00002\u00020\u0001¨\u0006\u0002"}, d2 = {"Lkotlin/reflect/KClassifier;", "", "kotlin-stdlib"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface KClassifier {
}
