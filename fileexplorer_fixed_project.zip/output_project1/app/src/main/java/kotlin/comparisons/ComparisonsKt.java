package kotlin.comparisons;

import kotlin.Metadata;

/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"kotlin/comparisons/ComparisonsKt__ComparisonsKt", "kotlin/comparisons/ComparisonsKt___ComparisonsJvmKt", "kotlin/comparisons/ComparisonsKt___ComparisonsKt"}, k = 4, mv = {1, 9, 0}, xi = 49)
public final class ComparisonsKt extends ComparisonsKt___ComparisonsKt {
    private ComparisonsKt() {
    }
}
