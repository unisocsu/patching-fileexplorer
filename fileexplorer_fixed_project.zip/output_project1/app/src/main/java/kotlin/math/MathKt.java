package kotlin.math;

import kotlin.Metadata;

/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"kotlin/math/MathKt__MathHKt", "kotlin/math/MathKt__MathJVMKt"}, k = 4, mv = {1, 9, 0}, xi = 49)
public final class MathKt extends MathKt__MathJVMKt {
    public static final double E = 2.718281828459045d;
    public static final double PI = 3.141592653589793d;

    private MathKt() {
    }
}
