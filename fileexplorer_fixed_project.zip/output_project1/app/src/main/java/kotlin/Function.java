package kotlin;

/* JADX INFO: compiled from: Function.kt */
/* JADX INFO: loaded from: classes.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0000\bf\u0018\u0000*\u0006\b\u0000\u0010\u0001 \u00012\u00020\u0002¨\u0006\u0003"}, d2 = {"Lkotlin/Function;", "R", "", "kotlin-stdlib"}, k = 1, mv = {1, 9, 0}, xi = 48)
public interface Function<R> {
}
